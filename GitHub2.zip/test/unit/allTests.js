/*
@to call all of the files supporting unit test cases
*/
sap.ui.define([
	"./model/models",
	"./model/formatter",
	"./controller/ListSelector"
], function() {
	"use strict";
});