/**
 * @Application where other views are placed 
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(BaseController) {
	"use strict";
	return BaseController.extend("GitHubGitHub.controller.App", {});
});